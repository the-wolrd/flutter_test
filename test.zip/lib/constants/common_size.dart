const double common_gap = 14.0;
const double common_xxs_gap = 8;
const double common_l_gap = 16;
const double common_s_gap = 12;
const double common_ss_gap = 10;

const double avatar_size = 30;