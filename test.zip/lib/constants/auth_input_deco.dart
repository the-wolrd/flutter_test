import 'package:flutter/material.dart';

import 'common_size.dart';

InputDecoration textInputDecor(String hint) {
  return InputDecoration(
    hintText: hint,
    enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.grey[400]),
        borderRadius: BorderRadius.circular(common_s_gap)),
    errorBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.redAccent[400]),
        borderRadius: BorderRadius.circular(common_s_gap)),
    focusedErrorBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.redAccent[400]),
        borderRadius: BorderRadius.circular(common_s_gap)),
    focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.grey[700]),
        borderRadius: BorderRadius.circular(common_s_gap)),
    filled: true,
    fillColor: Colors.grey[100],
  );
}