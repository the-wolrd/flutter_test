import 'package:day1/constants/auth_input_deco.dart';
import 'package:day1/constants/common_size.dart';
import 'package:day1/home_page.dart';
import 'package:flutter/material.dart';

import 'or_divider.dart';

class SignUpForm extends StatefulWidget {
  @override
  _SignUpFormState createState() => _SignUpFormState();
}

class _SignUpFormState extends State<SignUpForm> {
  GlobalKey<FormState> _formkey = GlobalKey<FormState>();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _pwController = TextEditingController();
  TextEditingController _cpwController = TextEditingController();

  @override
  void dispose() {
    // TODO: implement dispose
    _emailController.dispose();
    _pwController.dispose();
    _cpwController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: Padding(
        padding: const EdgeInsets.all(common_gap),
        child: Form(
          key: _formkey,
          child: ListView(
            children: [
              SizedBox(
                height: common_l_gap,
              ),
              Image.asset('assets/images/insta_text_logo.png'),
              TextFormField(
                  cursorColor: Colors.black54,
                  controller: _emailController,
                  decoration: textInputDecor('Email'),
                  validator: (text) {
                    if (text.isNotEmpty && text.contains("@")) {
                      return null;
                    } else {
                      return "정확한 이메일 주소를 입력하세요";
                    }
                  }),
              SizedBox(
                height: common_gap,
              ),
              TextFormField(
                  obscureText: true,
                  cursorColor: Colors.black54,
                  controller: _pwController,
                  decoration: textInputDecor("Password"),
                  validator: (text) {
                    if (text.isNotEmpty && text.length > 5) {
                      return null;
                    } else {
                      return "제대로된 비밀번호 입력";
                    }
                  }),
              SizedBox(
                height: common_gap,
              ),
              TextFormField(
                  obscureText: true,
                  cursorColor: Colors.black54,
                  controller: _cpwController,
                  decoration: textInputDecor("confirm Password"),
                  validator: (text) {
                    if (text.isNotEmpty && _pwController.text == text) {
                      return null;
                    } else {
                      return "비밀번호가 일치하지않음";
                    }
                  }),
              SizedBox(
                height: common_s_gap,
              ),
              _submitButton(context),
              SizedBox(
                height: common_s_gap,
              ),
              OrDivider(),
              FlatButton.icon(
                onPressed: () {},
                icon: ImageIcon(AssetImage('assets/images/facebook.png')),
                label: Text("Login wiht Facebook"),
                textColor: Colors.blueAccent,
              )
            ],
          ),
        ),
      ),
    );
  }

  FlatButton _submitButton(BuildContext context) {
    return FlatButton(
      color: Colors.blue,
      onPressed: () {
        if (_formkey.currentState.validate()) {
          print("성공");
          Navigator.of(context).pushReplacement(
              MaterialPageRoute(builder: (context) => HomePage()));
        }
      },
      child: Text(
        "Join",
        style: TextStyle(color: Colors.white),
      ),
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(6)),
    );
  }
}
